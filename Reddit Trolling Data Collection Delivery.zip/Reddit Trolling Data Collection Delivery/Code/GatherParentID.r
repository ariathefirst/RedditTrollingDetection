#Author: Haoran Zhang
library(data.table)
setwd(file.path("Desktop/ecs192/dtml"))
# read the child data, and gather the column names
data <- fread("all.csv")
col_name <- names(data) 
p_names <- paste0("p_",col_name)
#add p_id to the the child data
id <- data$parent_id
pid <- substr(id,4,nchar(id))
data$pid <- pid
#id.csv : parent id needed for querying parent post
id <- paste0("'", pid, "',")
write.csv(id,"id.csv")