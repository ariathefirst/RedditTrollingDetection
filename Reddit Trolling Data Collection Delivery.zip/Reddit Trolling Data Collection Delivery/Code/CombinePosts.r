#Author: Haoran Zhang
library(data.table)
parent <- fread("all_parent.csv")
#pid: the parent id of the posts
#p_id : the id of the parents
data[data$pid == parent$id[1]]
colnames(parent) <- p_names
res <- cbind(data[data$pid == parent[1]$p_id],parent[1])
for ( i in 2:nrow(parent)) {
  res <- rbind(res,cbind(data[data$pid == parent[i]$p_id],parent[i]))
}
res <- res[order(res$author),]
write.csv(res,"all_result.csv")