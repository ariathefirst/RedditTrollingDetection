#Author:Haoran Zhang
library(data.table)
setwd(file.path("dtml"))

all_result <- fread("all_result.csv")
real_pid <- all_result$p_id
data <-fread("all.csv")
#real_pid : the id of the parent posts that actually exist
#all_pid: all the possible parent id's.
all_id <- data$parent_id
all_pid <- substr(all_id,4,nchar(all_id))
missing <- sapply(all_pid, function(x) {
  if (! (x %in% real_pid)) {
    x
  }
})
missing = unlist(missing)
write.csv(missing,"missing_p_id.csv")

